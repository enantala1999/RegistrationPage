import sys
sys.path.append(r'C:\Users\dell\Desktop\training\main_project_4\website')

def test_my_home_page():
    return True