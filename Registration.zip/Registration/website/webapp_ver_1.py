import flask

app = flask.Flask("MyAppVer-1")

@app.errorhandler(404)
def my_404_errorpage(err):
    return "404. That's an error. pls check....your network"

@app.route("/")
def my_home_page():
    return flask.render_template("index.html")

@app.route("/about")
def my_about_page():
    return flask.render_template("about.html")

@app.route("/contactus")
def my_contactus_page():
    return flask.render_template("contactus.html")

@app.route("/login")
def my_login_page():
    return flask.render_template("login.html")

@app.route("/newuser")
def my_register_page():
    return flask.render_template("newuserregister.html")

@app.route("/registeruser",methods=['POST'])
def my_registeruser_page():
    # All form data is captured in a dict 'flask.request.form'
    entered_username = flask.request.form.get('uname')
    entered_password1 = flask.request.form.get('password_1')
    entered_password2 = flask.request.form.get('password_2')
    entered_email = flask.request.form.get('email')
    entered_location = flask.request.form.get('location')
    if entered_password1 != entered_password2:
        return "Passwords didnt match.<br> <a href='/'>Go Back</a>"
    else:
        import sqlite3
        con = sqlite3.connect("my_main_db.sqlite3")
        cur=con.cursor()
        my_create_table_query = "CREATE TABLE IF NOT EXISTS registered_users (NAME VARCHAR(100),EMAILID VARCHAR(100),PASSWORD VARCHAR(100),LOCATION VARCHAR(100))"
        cur.execute(my_create_table_query)
        # Verify user already present or not
        cur.execute(f"SELECT name,emailid from registered_users where name='{entered_username}' OR emailid='{entered_email}'")
        result = cur.fetchone()
        print("result is : ",result)
        if result != None:
            return "email already present.<br> <a href='/'>Go Back</a>"
        else:
            my_insert_query = f'''INSERT INTO registered_users VALUES ('{entered_username}','{entered_email}','{entered_password1}','{entered_location}')'''
            cur.execute(my_insert_query)
            con.commit()
            return "Account Created Successfully.<br> <a href='/'>Go Back</a>"

@app.route("/validateuser",methods=['POST'])
def my_validateuser_page():
    # All form data is captured in a dict 'flask.request.form'
    entered_username = flask.request.form.get('username')
    entered_password = flask.request.form.get('password')
    if entered_username == '' or entered_password == '':
        return "Fields can't be empty.<br> <a href='/'>Go Back</a>"
    else:
        import sqlite3
        con = sqlite3.connect("my_main_db.sqlite3")
        cur=con.cursor()
        # Verify user already present or not
        cur.execute(f"SELECT name from registered_users where name='{entered_username}' and password = '{entered_password}'")
        result = cur.fetchone()
        if result == None:
            return "Invalid Credentials.<br> <a href='/'>Go Back</a>"
        else:
            return flask.render_template('loginhome.html')



if __name__ == "__main__":
    app.run(host='127.0.0.1',port=5000)